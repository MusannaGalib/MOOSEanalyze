from setuptools import setup, find_packages
from pathlib import Path

setup(
    name="MOOSEanalyze",
    version="0.0.1",
    author="Musanna Galib",  # Customize as needed
    author_email="galibubc@student.ubc.ca",
    description="A Python package for post-processing MOOSE data",
    long_description=(Path("README.md").read_text(encoding="utf-8")),
    long_description_content_type="text/markdown",
    url="https://github.com/MusannaGalib/MOOSEanalyze/",
    keywords="MOOSE, Post-processing, Pvpython-paraview",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=[
        "pandas>=1.1.5",
        "matplotlib>=3.3.3",
        "numpy>=1.19.4",
        "seaborn>=0.13.2"
        # 'vtk', # Uncomment if VTK is installable via pip
        # 'paraview', # Uncomment if Paraview is installable via pip
    ],
    entry_points={
        "console_scripts": [
            "your_script=your_package.module:function",
        ],
    },
)
